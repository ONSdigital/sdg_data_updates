library(testthat)
library(SDGupdater)

test_check("SDGupdater")
