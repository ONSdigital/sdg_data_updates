# Author: Emma Wood
# Date (start): 29/01/2021
# Purpose: To create csv data for country of occurrence: baby sex disaggregations for indicator 3.2.2
# Requirements:This script is called by compile_tables.R, which is called by update_indicator_main.R


country_of_occurrence_by_sex <- dplyr::filter(source_data, sheet == config$country_of_occurrence_by_sex_tab_name)


info_cells <- SDGupdater::get_info_cells(country_of_occurrence_by_sex, config$first_header_row_country_by_sex)
year <- SDGupdater::unique_to_string(info_cells$Year)
country <- SDGupdater::unique_to_string(info_cells$Country)

main_data <- country_of_occurrence_by_sex %>%
  SDGupdater::remove_blanks_and_info_cells(config$first_header_row_country_by_sex) %>%
  dplyr::mutate(character = suppressWarnings(SDGupdater::remove_superscripts(character)))

tidy_data <- main_data %>%
  unpivotr::behead("left-up", area_code) %>%
  unpivotr::behead("left-up", country) %>%
  unpivotr::behead("left", sex) %>%
  unpivotr::behead("up-left", measure) %>%
  unpivotr::behead("up-left", rate_type) %>%
  unpivotr::behead("up-left", life_event_age) %>%
  unpivotr::behead("up", baby_age) %>%
  dplyr::select(area_code, country, sex, measure, rate_type, life_event_age, baby_age,
         numeric)

clean_data <- tidy_data %>%
  dplyr::filter(!is.na(numeric)) %>% # to remove cells that are just ends of a header that have run on to the next row
  dplyr::mutate(country = trimws(country,  which = "both"),
         sex = trimws(sex,  which = "both"))

data_for_calculations <- clean_data %>%
  tidyr::pivot_wider(names_from = c(measure, rate_type, life_event_age, baby_age),
              values_from = numeric)

# TO DO: write function to remove NAs from column headings OR preferably, look into NLP to make having exact column headings unimportant

# In 2018 data 'Numbers' heading hasn't been pulled all the way to the left, so Births aren't included under that heading.
if ("NA_NA_Births_Live births" %in% colnames(data_for_calculations)) {
  headings_standardised <- dplyr::rename(data_for_calculations, `Numbers_NA_Births_Live births` = `NA_NA_Births_Live births`)
} else {
  headings_standardised <- data_for_calculations
}

late_neonatal <- headings_standardised %>%
  dplyr::mutate(Numbers_Deaths_Late_neonatal = `Numbers_NA_Deaths under 1_Neonatal` - `Numbers_NA_Deaths under 1_Early`) %>%
  dplyr::mutate(Rates_Late_neonatal = SDGupdater::calculate_valid_rates_per_1000(Numbers_Deaths_Late_neonatal,
                                                        `Numbers_NA_Births_Live births`, config$decimal_places),
         # overall neonatal rates are calculated already in the download, so we can check our calcs against these
         Rates_Neonatal_check = SDGupdater::calculate_valid_rates_per_1000(`Numbers_NA_Deaths under 1_Neonatal`,
                                                         `Numbers_NA_Births_Live births`, config$decimal_places))

number_of_rate_calculation_mismatches <- SDGupdater::count_mismatches(late_neonatal$Rates_Neonatal_check, late_neonatal$`Rates_Per 1,000  live births_Childhood deaths_Neonatal`)

relevant_columns <- late_neonatal %>%
  dplyr::select(country, sex, area_code,
         `Rates_Per 1,000  live births_Childhood deaths_Early`,
         Rates_Late_neonatal,
         `Rates_Per 1,000  live births_Childhood deaths_Neonatal`)

data_in_csv_format <- relevant_columns %>%
  tidyr::pivot_longer(
    cols = starts_with("Rates"),
    names_to = "Neonatal_period",
    values_to = "Value")

clean_csv_data_country_by_sex <- data_in_csv_format %>%
  dplyr::mutate(Neonatal_period = dplyr::case_when(
    Neonatal_period == "Rates_Per 1,000  live births_Childhood deaths_Early" ~ "Early neonatal",
    Neonatal_period == "Rates_Late_neonatal" ~ "Late neonatal",
    Neonatal_period == "Rates_Per 1,000  live births_Childhood deaths_Neonatal" ~ ""),
    sex = ifelse(sex == "All", "", sex)) %>%
  dplyr::rename(`Neonatal period` = Neonatal_period,
         Sex = sex,
         Country = country,
         GeoCode = area_code) %>%
  dplyr::mutate(Year = year,
         Birthweight = "",
         Age = "",
         Region = "",
         `Health board` = "",
         Country = ifelse(Country == "United Kingdom", "", Country),
         GeoCode = ifelse(Country == "England and Wales", "K04000001", GeoCode),
         Sex = dplyr::case_when(
           Sex == "P" ~ "",
           Sex == "M" ~ "Male",
           Sex == "F" ~ "Female",
           TRUE ~ Sex))

SDGupdater::multiple_year_warning(config$filename, config$country_of_occurrence_by_sex_tab_name,"country of occurrence by sex")
SDGupdater::multiple_country_warning(config$filename, config$country_of_occurrence_by_sex_tab_name,"country of occurrence by sex")

if(number_of_rate_calculation_mismatches != 0){
  warning(paste("check of rate caclulations has failed.",
                number_of_rate_calculation_mismatches, "of", nrow(late_neonatal), "neonatal death rates do not match.",
                "Calculations are performed in the block of code where 'late_neonatal' is created."))
}

# clean up environment as the same names are used for multiple scripts called in the same session
rm(clean_data,
   data_for_calculations, data_in_csv_format,
   headings_standardised,
   info_cells, late_neonatal,
   tidy_data, relevant_columns,
   country, year, number_of_rate_calculation_mismatches)


